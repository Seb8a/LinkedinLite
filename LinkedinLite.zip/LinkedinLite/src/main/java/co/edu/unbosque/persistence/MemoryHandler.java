package co.edu.unbosque.persistence;

import co.edu.unbosque.model.Formulario;

public class MemoryHandler implements FormularioDAO {

	@Override
	public String getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(Object x) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Object x) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object find(Object x) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Object x, Object y) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}
